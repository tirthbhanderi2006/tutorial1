<!-- resources/views/sum-of-digits.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Sum of Digits Calculator</title>
</head>
<body>
    <h2>Sum of Digits Calculator</h2>

    <form method="POST" action="<?php echo e(route('sum-of-digits.calculate')); ?>">
        <?php echo csrf_field(); ?>
        <label for="number">Enter a number:</label><br>
        <input type="number" id="number" name="number" value="<?php echo e(old('number')); ?>" required><br><br>
        <button type="submit">Calculate</button>
    </form>

    <?php if(isset($sumOfDigits)): ?>
        <p>Sum of digits of <?php echo e($number); ?> is <?php echo e($sumOfDigits); ?>.</p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\tutorial\resources\views/sum-of-digits.blade.php ENDPATH**/ ?>