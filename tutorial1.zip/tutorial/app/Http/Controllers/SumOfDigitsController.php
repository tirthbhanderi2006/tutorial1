<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SumOfDigitsController extends Controller
{
    public function index()
    {
        return view('sum-of-digits');
    }

    public function calculate(Request $request)
    {
        $request->validate([
            'number' => 'required|integer|min:0', // Ensure input is a non-negative integer
        ]);

        $number = $request->input('number');
        $sumOfDigits = $this->sumOfDigits($number);

        return view('sum-of-digits', ['number' => $number, 'sumOfDigits' => $sumOfDigits]);
    }

    private function sumOfDigits($number)
    {
        $sum = 0;
        while ($number != 0) {
            $sum += $number % 10; // Add last digit to sum
            $number = (int)($number / 10); // Remove last digit from number
        }
        return $sum;
    }
}
