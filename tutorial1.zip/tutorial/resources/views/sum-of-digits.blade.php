<!-- resources/views/sum-of-digits.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Sum of Digits Calculator</title>
</head>
<body>
    <h2>Sum of Digits Calculator</h2>

    <form method="POST" action="{{ route('sum-of-digits.calculate') }}">
        @csrf
        <label for="number">Enter a number:</label><br>
        <input type="number" id="number" name="number" value="{{ old('number') }}" required><br><br>
        <button type="submit">Calculate</button>
    </form>

    @isset($sumOfDigits)
        <p>Sum of digits of {{ $number }} is {{ $sumOfDigits }}.</p>
    @endisset
</body>
</html>
